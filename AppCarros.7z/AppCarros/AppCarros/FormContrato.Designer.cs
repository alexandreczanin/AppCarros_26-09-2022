﻿namespace AppCarros
{
    partial class FormContrato
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.btnLocalizarIdVeiculo = new System.Windows.Forms.Button();
            this.lblIdVeiculo = new System.Windows.Forms.Label();
            this.txtIdCarro = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpDevolucao = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtIcContrato = new System.Windows.Forms.TextBox();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.btnLocalizar = new System.Windows.Forms.Button();
            this.btnLocalizarNomeFuncionario = new System.Windows.Forms.Button();
            this.btnLocalizarIdFuncionario = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCPFFuncionario = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTelefoneFuncionario = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtIdFuncionario = new System.Windows.Forms.TextBox();
            this.btnNomeCliente = new System.Windows.Forms.Button();
            this.btnIdCliente = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCPFCliente = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTelefoneCliente = new System.Windows.Forms.TextBox();
            this.t = new System.Windows.Forms.Label();
            this.txtNomeCliente = new System.Windows.Forms.TextBox();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.txtIdCliente = new System.Windows.Forms.TextBox();
            this.DGV = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPreco
            // 
            this.txtPreco.BackColor = System.Drawing.SystemColors.Control;
            this.txtPreco.Location = new System.Drawing.Point(473, 260);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(81, 24);
            this.txtPreco.TabIndex = 44;
            // 
            // btnLocalizarIdVeiculo
            // 
            this.btnLocalizarIdVeiculo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnLocalizarIdVeiculo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizarIdVeiculo.ForeColor = System.Drawing.Color.White;
            this.btnLocalizarIdVeiculo.Location = new System.Drawing.Point(803, 443);
            this.btnLocalizarIdVeiculo.Name = "btnLocalizarIdVeiculo";
            this.btnLocalizarIdVeiculo.Size = new System.Drawing.Size(101, 31);
            this.btnLocalizarIdVeiculo.TabIndex = 43;
            this.btnLocalizarIdVeiculo.Text = "Localizar";
            this.btnLocalizarIdVeiculo.UseVisualStyleBackColor = false;
            // 
            // lblIdVeiculo
            // 
            this.lblIdVeiculo.AutoSize = true;
            this.lblIdVeiculo.Location = new System.Drawing.Point(712, 420);
            this.lblIdVeiculo.Name = "lblIdVeiculo";
            this.lblIdVeiculo.Size = new System.Drawing.Size(108, 18);
            this.lblIdVeiculo.TabIndex = 42;
            this.lblIdVeiculo.Text = "Id do veiculo:";
            // 
            // txtIdCarro
            // 
            this.txtIdCarro.BackColor = System.Drawing.SystemColors.Control;
            this.txtIdCarro.Location = new System.Drawing.Point(716, 443);
            this.txtIdCarro.Name = "txtIdCarro";
            this.txtIdCarro.Size = new System.Drawing.Size(81, 24);
            this.txtIdCarro.TabIndex = 41;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(712, 356);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(144, 18);
            this.label11.TabIndex = 40;
            this.label11.Text = "Marca do Veiculo:";
            // 
            // txtMarca
            // 
            this.txtMarca.BackColor = System.Drawing.Color.DarkGray;
            this.txtMarca.Enabled = false;
            this.txtMarca.Location = new System.Drawing.Point(716, 379);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.ReadOnly = true;
            this.txtMarca.Size = new System.Drawing.Size(81, 24);
            this.txtMarca.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(712, 296);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 18);
            this.label10.TabIndex = 38;
            this.label10.Text = "Modelo do Veiculo:";
            // 
            // txtModelo
            // 
            this.txtModelo.BackColor = System.Drawing.Color.DarkGray;
            this.txtModelo.Enabled = false;
            this.txtModelo.Location = new System.Drawing.Point(716, 319);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.ReadOnly = true;
            this.txtModelo.Size = new System.Drawing.Size(81, 24);
            this.txtModelo.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(715, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(146, 18);
            this.label9.TabIndex = 36;
            this.label9.Text = "Dia de Devolução:";
            // 
            // dtpDevolucao
            // 
            this.dtpDevolucao.Location = new System.Drawing.Point(716, 202);
            this.dtpDevolucao.Name = "dtpDevolucao";
            this.dtpDevolucao.Size = new System.Drawing.Size(200, 24);
            this.dtpDevolucao.TabIndex = 35;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLimpar);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtPreco);
            this.groupBox1.Controls.Add(this.btnLocalizarIdVeiculo);
            this.groupBox1.Controls.Add(this.lblIdVeiculo);
            this.groupBox1.Controls.Add(this.txtIdCarro);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtMarca);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtModelo);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.dtpDevolucao);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtIcContrato);
            this.groupBox1.Controls.Add(this.btnExcluir);
            this.groupBox1.Controls.Add(this.btnCadastrar);
            this.groupBox1.Controls.Add(this.btnLocalizar);
            this.groupBox1.Controls.Add(this.btnLocalizarNomeFuncionario);
            this.groupBox1.Controls.Add(this.btnLocalizarIdFuncionario);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtCPFFuncionario);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtTelefoneFuncionario);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtNomeFuncionario);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtIdFuncionario);
            this.groupBox1.Controls.Add(this.btnNomeCliente);
            this.groupBox1.Controls.Add(this.btnIdCliente);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCPFCliente);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtTelefoneCliente);
            this.groupBox1.Controls.Add(this.t);
            this.groupBox1.Controls.Add(this.txtNomeCliente);
            this.groupBox1.Controls.Add(this.lblCliente);
            this.groupBox1.Controls.Add(this.lblId);
            this.groupBox1.Controls.Add(this.txtIdCliente);
            this.groupBox1.Controls.Add(this.DGV);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(58, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1179, 697);
            this.groupBox1.TabIndex = 173;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Contrato:";
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(815, 99);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(101, 31);
            this.btnLimpar.TabIndex = 48;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(578, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 18);
            this.label13.TabIndex = 47;
            this.label13.Text = "Dia de Hoje:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.DarkGray;
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Location = new System.Drawing.Point(524, 45);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(273, 24);
            this.dateTimePicker1.TabIndex = 46;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(469, 237);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 18);
            this.label12.TabIndex = 45;
            this.label12.Text = "Preço do Aluguel:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(712, 237);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 18);
            this.label8.TabIndex = 34;
            this.label8.Text = "Id do contrato:";
            // 
            // txtIcContrato
            // 
            this.txtIcContrato.BackColor = System.Drawing.SystemColors.Control;
            this.txtIcContrato.Location = new System.Drawing.Point(716, 260);
            this.txtIcContrato.Name = "txtIcContrato";
            this.txtIcContrato.Size = new System.Drawing.Size(81, 24);
            this.txtIcContrato.TabIndex = 33;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.ForeColor = System.Drawing.Color.White;
            this.btnExcluir.Location = new System.Drawing.Point(815, 62);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(101, 31);
            this.btnExcluir.TabIndex = 32;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = false;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrar.ForeColor = System.Drawing.Color.White;
            this.btnCadastrar.Location = new System.Drawing.Point(815, 25);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(101, 31);
            this.btnCadastrar.TabIndex = 31;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = false;
            // 
            // btnLocalizar
            // 
            this.btnLocalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnLocalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizar.ForeColor = System.Drawing.Color.White;
            this.btnLocalizar.Location = new System.Drawing.Point(803, 260);
            this.btnLocalizar.Name = "btnLocalizar";
            this.btnLocalizar.Size = new System.Drawing.Size(101, 31);
            this.btnLocalizar.TabIndex = 30;
            this.btnLocalizar.Text = "Localizar";
            this.btnLocalizar.UseVisualStyleBackColor = false;
            // 
            // btnLocalizarNomeFuncionario
            // 
            this.btnLocalizarNomeFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnLocalizarNomeFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizarNomeFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnLocalizarNomeFuncionario.Location = new System.Drawing.Point(515, 144);
            this.btnLocalizarNomeFuncionario.Name = "btnLocalizarNomeFuncionario";
            this.btnLocalizarNomeFuncionario.Size = new System.Drawing.Size(179, 35);
            this.btnLocalizarNomeFuncionario.TabIndex = 29;
            this.btnLocalizarNomeFuncionario.Text = "Localizar por Nome";
            this.btnLocalizarNomeFuncionario.UseVisualStyleBackColor = false;
            // 
            // btnLocalizarIdFuncionario
            // 
            this.btnLocalizarIdFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnLocalizarIdFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizarIdFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnLocalizarIdFuncionario.Location = new System.Drawing.Point(439, 91);
            this.btnLocalizarIdFuncionario.Name = "btnLocalizarIdFuncionario";
            this.btnLocalizarIdFuncionario.Size = new System.Drawing.Size(161, 37);
            this.btnLocalizarIdFuncionario.TabIndex = 28;
            this.btnLocalizarIdFuncionario.Text = "Localizar por Id";
            this.btnLocalizarIdFuncionario.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(348, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 18);
            this.label1.TabIndex = 27;
            this.label1.Text = "CPF:";
            // 
            // txtCPFFuncionario
            // 
            this.txtCPFFuncionario.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtCPFFuncionario.Enabled = false;
            this.txtCPFFuncionario.Location = new System.Drawing.Point(352, 260);
            this.txtCPFFuncionario.Name = "txtCPFFuncionario";
            this.txtCPFFuncionario.ReadOnly = true;
            this.txtCPFFuncionario.Size = new System.Drawing.Size(81, 24);
            this.txtCPFFuncionario.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(348, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 18);
            this.label4.TabIndex = 25;
            this.label4.Text = "Telefone:";
            // 
            // txtTelefoneFuncionario
            // 
            this.txtTelefoneFuncionario.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtTelefoneFuncionario.Enabled = false;
            this.txtTelefoneFuncionario.Location = new System.Drawing.Point(352, 204);
            this.txtTelefoneFuncionario.Name = "txtTelefoneFuncionario";
            this.txtTelefoneFuncionario.ReadOnly = true;
            this.txtTelefoneFuncionario.Size = new System.Drawing.Size(81, 24);
            this.txtTelefoneFuncionario.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(348, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 18);
            this.label5.TabIndex = 23;
            this.label5.Text = "Nome:";
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtNomeFuncionario.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtNomeFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.txtNomeFuncionario.Location = new System.Drawing.Point(352, 148);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(157, 24);
            this.txtNomeFuncionario.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(348, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 18);
            this.label6.TabIndex = 21;
            this.label6.Text = "Info Funcionario:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(348, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 18);
            this.label7.TabIndex = 20;
            this.label7.Text = "Id:";
            // 
            // txtIdFuncionario
            // 
            this.txtIdFuncionario.BackColor = System.Drawing.SystemColors.Control;
            this.txtIdFuncionario.Location = new System.Drawing.Point(352, 96);
            this.txtIdFuncionario.Name = "txtIdFuncionario";
            this.txtIdFuncionario.Size = new System.Drawing.Size(81, 24);
            this.txtIdFuncionario.TabIndex = 19;
            // 
            // btnNomeCliente
            // 
            this.btnNomeCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnNomeCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNomeCliente.ForeColor = System.Drawing.Color.White;
            this.btnNomeCliente.Location = new System.Drawing.Point(163, 144);
            this.btnNomeCliente.Name = "btnNomeCliente";
            this.btnNomeCliente.Size = new System.Drawing.Size(179, 35);
            this.btnNomeCliente.TabIndex = 18;
            this.btnNomeCliente.Text = "Localizar por Nome";
            this.btnNomeCliente.UseVisualStyleBackColor = false;
            // 
            // btnIdCliente
            // 
            this.btnIdCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.btnIdCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIdCliente.ForeColor = System.Drawing.Color.White;
            this.btnIdCliente.Location = new System.Drawing.Point(127, 91);
            this.btnIdCliente.Name = "btnIdCliente";
            this.btnIdCliente.Size = new System.Drawing.Size(161, 37);
            this.btnIdCliente.TabIndex = 17;
            this.btnIdCliente.Text = "Localizar por Id";
            this.btnIdCliente.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "CPF:";
            // 
            // txtCPFCliente
            // 
            this.txtCPFCliente.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtCPFCliente.Enabled = false;
            this.txtCPFCliente.Location = new System.Drawing.Point(40, 260);
            this.txtCPFCliente.Name = "txtCPFCliente";
            this.txtCPFCliente.ReadOnly = true;
            this.txtCPFCliente.Size = new System.Drawing.Size(81, 24);
            this.txtCPFCliente.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 18);
            this.label2.TabIndex = 14;
            this.label2.Text = "Telefone:";
            // 
            // txtTelefoneCliente
            // 
            this.txtTelefoneCliente.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtTelefoneCliente.Enabled = false;
            this.txtTelefoneCliente.Location = new System.Drawing.Point(40, 204);
            this.txtTelefoneCliente.Name = "txtTelefoneCliente";
            this.txtTelefoneCliente.ReadOnly = true;
            this.txtTelefoneCliente.Size = new System.Drawing.Size(81, 24);
            this.txtTelefoneCliente.TabIndex = 13;
            // 
            // t
            // 
            this.t.AutoSize = true;
            this.t.Location = new System.Drawing.Point(36, 125);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(58, 18);
            this.t.TabIndex = 12;
            this.t.Text = "Nome:";
            // 
            // txtNomeCliente
            // 
            this.txtNomeCliente.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtNomeCliente.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtNomeCliente.BackColor = System.Drawing.SystemColors.Control;
            this.txtNomeCliente.Location = new System.Drawing.Point(40, 148);
            this.txtNomeCliente.Name = "txtNomeCliente";
            this.txtNomeCliente.Size = new System.Drawing.Size(117, 24);
            this.txtNomeCliente.TabIndex = 11;
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Location = new System.Drawing.Point(36, 44);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(98, 18);
            this.lblCliente.TabIndex = 10;
            this.lblCliente.Text = "Info Cliente:";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(36, 73);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(26, 18);
            this.lblId.TabIndex = 9;
            this.lblId.Text = "Id:";
            // 
            // txtIdCliente
            // 
            this.txtIdCliente.BackColor = System.Drawing.SystemColors.Control;
            this.txtIdCliente.Location = new System.Drawing.Point(40, 96);
            this.txtIdCliente.Name = "txtIdCliente";
            this.txtIdCliente.Size = new System.Drawing.Size(81, 24);
            this.txtIdCliente.TabIndex = 5;
            // 
            // DGV
            // 
            this.DGV.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(69)))));
            this.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(53)))));
            this.DGV.Location = new System.Drawing.Point(40, 310);
            this.DGV.Name = "DGV";
            this.DGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DGV.Size = new System.Drawing.Size(636, 234);
            this.DGV.TabIndex = 4;
            // 
            // FormContrato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormContrato";
            this.Text = "FormContrato";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Button btnLocalizarIdVeiculo;
        private System.Windows.Forms.Label lblIdVeiculo;
        private System.Windows.Forms.TextBox txtIdCarro;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpDevolucao;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtIcContrato;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Button btnLocalizar;
        private System.Windows.Forms.Button btnLocalizarNomeFuncionario;
        private System.Windows.Forms.Button btnLocalizarIdFuncionario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCPFFuncionario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTelefoneFuncionario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtIdFuncionario;
        private System.Windows.Forms.Button btnNomeCliente;
        private System.Windows.Forms.Button btnIdCliente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCPFCliente;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTelefoneCliente;
        private System.Windows.Forms.Label t;
        private System.Windows.Forms.TextBox txtNomeCliente;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtIdCliente;
        private System.Windows.Forms.DataGridView DGV;
    }
}